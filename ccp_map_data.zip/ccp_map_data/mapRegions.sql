-- phpMyAdmin SQL Dump
-- version 2.7.0-pl2
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 07, 2006 at 02:16 PM
-- Server version: 3.23.49
-- PHP Version: 4.1.2
-- 
-- Database: `db0754506751`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `mapRegions`
-- 

CREATE TABLE `mapRegions` (
  `regionID` int(11) default NULL,
  `regionName` char(100) default NULL
) TYPE=MyISAM;

-- 
-- Dumping data for table `mapRegions`
-- 

INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000001, 'Derelik');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000002, 'The Forge');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000003, 'Vale of the Silent');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000004, 'UUA-F4');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000005, 'Detorid');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000006, 'Wicked Creek');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000007, 'Cache');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000008, 'Scalding Pass');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000009, 'Insmother');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000010, 'Tribute');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000011, 'Great Wildlands');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000012, 'Curse');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000013, 'LQ-0QN');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000014, 'Catch');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000015, 'Venal');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000016, 'Lonetrek');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000017, 'J7HZ-F');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000018, 'VU-WU2');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000019, 'A821-A');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000020, 'Tash-Murkon');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000021, '6HL8-L');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000022, 'Stain');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000023, 'Pure Blind');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000025, 'Immensea');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000027, '7-KXBJ');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000028, 'Molden Heath');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000029, 'Geminate');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000030, 'Heimatar');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000031, 'Impass');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000032, 'Sinq Laison');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000033, 'The Citadel');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000034, '87-1CW');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000035, 'Deklein');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000036, 'Devoid');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000037, 'Everyshore');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000038, 'The Bleak Lands');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000039, 'Esoteria');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000040, 'G5KW-3');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000041, 'Syndicate');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000042, 'Metropolis');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000043, 'Domain');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000044, 'Solitude');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000045, 'Tenal');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000046, 'Fade');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000047, 'Providence');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000048, 'Placid');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000049, 'Khanid');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000050, 'Querious');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000051, 'Cloud Ring');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000052, 'Kador');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000053, 'H3J8-U');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000054, 'Aridia');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000055, 'Branch');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000056, 'Feythabolis');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000057, 'Outer Ring');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000058, 'Fountain');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000059, 'Paragon Soul');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000060, 'Delve');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000061, 'Tenerifis');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000062, 'Omist');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000063, 'Period Basis');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000064, 'Essence');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000065, 'Kor-Azor');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000066, 'S-I6VU');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000067, 'Genesis');
INSERT INTO `mapRegions` (`regionID`, `regionName`) VALUES (10000068, 'Verge Vendor');
